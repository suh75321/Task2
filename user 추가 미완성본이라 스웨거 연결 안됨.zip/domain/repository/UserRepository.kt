package com.teamsparta.courseregistration2.domain.repository

import com.teamsparta.courseregistration2.domain.User
import org.springframework.data.jpa.repository.JpaRepository

interface UserRepository : JpaRepository<User, Long>