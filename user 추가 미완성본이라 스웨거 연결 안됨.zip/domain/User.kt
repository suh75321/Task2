package com.teamsparta.courseregistration2.domain

import jakarta.persistence.*

@Entity
@Table(name = "app_user")
class User (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long? = null,

    var nickname: String = ""
)