package com.teamsparta.courseregistration2.domain.service

import com.teamsparta.courseregistration2.domain.Task
import com.teamsparta.courseregistration2.domain.repository.TaskRepository
import com.teamsparta.courseregistration2.domain.repository.UserRepository
import org.springframework.data.domain.Sort
import org.springframework.stereotype.Service
import java.util.*

@Service
class TaskService(private val taskRepository: TaskRepository, private val userRepository: UserRepository) {

    fun getAllTasks(): List<Task> {
        val tasks = taskRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"))
        return tasks
    }

    fun getTaskById(id: Long): Optional<Task> {
        return taskRepository.findById(id)
    }

    fun createTask(userId: Long, task: Task): Task {
        val user = userRepository.findById(userId).orElseThrow { NoSuchElementException("No user found with ID $userId") }
        task.writer = user.nickname
        return taskRepository.save(task)
    }

    fun updateTask(id: Long, newTask: Task): Optional<Task> {
        return taskRepository.findById(id).map { existingTask ->
            existingTask.title = newTask.title
            existingTask.content = newTask.content
            existingTask.writer = newTask.writer
            taskRepository.save(existingTask)
        }
    }

    fun deleteTask(id: Long) {
        return taskRepository.deleteById(id)
    }

    fun deleteAllTasks() {
        TODO("Not yet implemented")
    }


}